--prep_customers_p1.sql--
--create table--
DROP TABLE IF EXISTS customers;
CREATE TABLE customers
WITH cte1 AS (
	SELECT
		user_id, MAX(timestamp) AS time 
	FROM
		pageviews_tmp 
	GROUP BY
		user_id),
	cte2 AS (
	SELECT
		p.user_id, p.user_agent, p.timestamp 
	FROM
		pageviews_tmp p 
	JOIN cte1 ON p.user_id = cte1.user_id 
		AND p.timestamp = cte1.time) 
SELECT
	c.user_id, c.first_name, c.last_name, c.job_title, cte2.user_agent AS operating_system 
FROM
	customers_tmp c 
JOIN cte2 ON c.user_id = cte2.user_id;
