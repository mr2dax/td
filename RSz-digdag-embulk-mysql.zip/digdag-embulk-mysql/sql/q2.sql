--q2.sql--
--top 3 users--
WITH cte AS (
	SELECT
		user_id, MAX(timestamp) AS most_recent_timestamp 
	FROM
		pageviews 
	WHERE
		user_id IN (
			SELECT
				user_id
			FROM
				pageviews 
			WHERE
				url LIKE '%.gov%') 
	GROUP BY
		user_id 
	ORDER BY
		COUNT(url) DESC 
    LIMIT 3)
SELECT
	user_id, url AS last_page_viewed 
FROM
	pageviews 
WHERE
	user_id IN (
		SELECT
			user_id 
		FROM
			cte 
		WHERE
			timestamp = most_recent_timestamp)
GROUP BY
	user_id, url
ORDER BY
	timestamp DESC;
