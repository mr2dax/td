--prep_pageviews.sql--
DROP TABLE IF EXISTS pageviews;
CREATE TABLE pageviews 
SELECT
	user_id, url, user_agent, timestamp
FROM
	pageviews_tmp
WHERE
	user_id IN (
		SELECT
			user_id
		FROM
			customers_tmp
		WHERE
			job_title NOT LIKE '%Sales%');
