# Embulk-Digdag worflow using MySQL - Treasure Data SE Coding Challenge
# by mr2dax
# 2022-05-18
Utilize Embulk and Digdag to load CSVs to a MySQL db, then prep the data and run a few SQL queries.

Specs:
1. VMWare Workstation Player (16.2.3, default settings)
2. Ubuntu (22.04 LTS, minimal installation)

Requirements / Assumptions:
1. Oracle Java (JDK 18 Linux x64) + Java path set correctly
2. root privileges
3. DigDag (0.10.2)
4. Embulk (0.9.24) + embulk-output-mysql gem
5. MySQL (MariaDB Server 10.6.7)

DB Setup:
1. Login to MariaDB with root.
```
$ sudo mariadb
```
2. Create td_coding_challenge database and digdag non-root account with grant all privileges on said database.
```
MariaDB> CREATE DATABASE td_coding_challenge DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
MariaDB> GRANT ALL ON td_coding_challenge.* TO 'digdag'@'localhost' IDENTIFIED BY 'digdag' WITH GRANT OPTION;
MariaDB> FLUSH PRIVILEGES;
MariaDB> exit
```
3. Test digdag account.
```
$ mariadb -u digdag -p
MariaDB [(none)]> SHOW DATABASES;
```
Note: password is the same as the account name.

How to run:
```
$ sudo -s
$ cd path/to/folder
$ digdag secrets --local --set mysql.password=digdag
$ digdag run embulk_digdag_mysql.dig -O log/task
```
Note: add --rerun flag to the last command if you are re-running the workflow (not your first run).
